CREATE OR REPLACE FUNCTION fnc_fibonacci(pstop integer DEFAULT 10)
RETURNS TABLE (
    num integer
) AS
$$
DECLARE
    f1 integer := 0;
    f2 integer := 1;
    next integer;
BEGIN
    num := f1;
    RETURN NEXT;
    WHILE f2 < pstop
        LOOP
            num := f2;
            RETURN NEXT;
            next := f2 + f1;
            f1 := f2;
            f2 := next;
        END LOOP;
    RETURN;
END;
$$ LANGUAGE plpgsql;

SELECT * FROM fnc_fibonacci(100);
SELECT * FROM fnc_fibonacci();