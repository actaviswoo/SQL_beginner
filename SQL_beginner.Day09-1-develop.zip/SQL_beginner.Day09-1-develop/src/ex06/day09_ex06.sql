CREATE OR REPLACE FUNCTION fnc_person_visits_and_eats_on_date(IN pperson varchar DEFAULT 'Dmitriy', 
									   IN pprice numeric DEFAULT 500, 
									   IN pdate date DEFAULT '2022-01-08')
RETURNS TABLE
(
name varchar
) AS
$$
BEGIN
RETURN QUERY
SELECT DISTINCT pizzeria.name
FROM pizzeria
JOIN person_visits ON pizzeria.id = person_visits.pizzeria_id
JOIN person ON person.id = person_visits.person_id
JOIN menu ON pizzeria.id = menu.pizzeria_id
WHERE pdate = visit_date AND pperson = person.name AND menu.price < pprice;
END;
$$ LANGUAGE PLPGSQL;

SELECT *
FROM fnc_person_visits_and_eats_on_date(pprice := 800);


SELECT *
FROM fnc_person_visits_and_eats_on_date(pperson := 'Anna', pprice := 1300, pdate := '2022-01-01');