SELECT person.id, person.name, age, gender, address, pizzeria.id, pizzeria.name, rating
FROM pizzeria, person
ORDER BY person.id, pizzeria.id