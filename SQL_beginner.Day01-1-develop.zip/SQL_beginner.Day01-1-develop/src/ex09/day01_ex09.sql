SELECT name
FROM pizzeria
WHERE pizzeria.id NOT IN (
	SELECT pizzeria_id 
	FROM person_visits
);
SELECT name
FROM pizzeria
WHERE NOT EXISTS (
	SELECT name 
  	FROM person_visits
  	WHERE pizzeria.id = person_visits.pizzeria_id
); 
