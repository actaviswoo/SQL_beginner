WITH visits_orders AS (
(SELECT pizzeria.name AS name, COUNT(*) AS count
FROM person_order po
JOIN menu m ON po.menu_id = m.id
JOIN pizzeria ON m.pizzeria_id = pizzeria.id
GROUP BY pizzeria.name
ORDER BY count DESC)
UNION
(SELECT pizzeria.name AS name, COUNT(*) AS count
FROM person_visits pv
JOIN pizzeria ON pv.pizzeria_id = pizzeria.id
GROUP BY pizzeria.name
ORDER BY count DESC)
)
SELECT name, SUM(count) AS total_count
FROM visits_orders
GROUP BY name
ORDER BY total_count DESC, name