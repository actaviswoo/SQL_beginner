SELECT miss::date FROM generate_series(
'2022-01-01'::date, 
'2022-01-10'::date, 
INTERVAL '1 day'
) miss
LEFT JOIN person_visits ON miss = person_visits.visit_date AND (person_visits.person_id = 1 OR person_visits.person_id = 2)
WHERE person_visits.person_id IS NULL
ORDER BY 1