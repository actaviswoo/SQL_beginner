WITH dates AS (
    SELECT DATE '2022-01-01' + (n || ' days')::interval AS miss
    FROM generate_series(0, 9) n
)
SELECT dates.miss::date
FROM dates
LEFT JOIN person_visits ON dates.miss = person_visits.visit_date AND (person_visits.person_id = 1 OR person_visits.person_id = 2)
WHERE person_visits.person_id IS NULL
ORDER BY dates.miss