SELECT DISTINCT person.name
FROM person
JOIN person_order ON person_order.person_id = person.id
JOIN menu ON menu.id = person_order.menu_id
WHERE (pizza_name = 'pepperoni pizza' OR pizza_name = 'cheese pizza') AND (gender = 'female')
GROUP BY person.name
HAVING COUNT(person.name) > 1