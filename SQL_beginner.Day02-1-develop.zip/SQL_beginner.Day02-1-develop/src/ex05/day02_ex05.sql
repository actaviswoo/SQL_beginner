SELECT name
FROM person
WHERE age > 25 AND gender = 'female'
ORDER BY 1