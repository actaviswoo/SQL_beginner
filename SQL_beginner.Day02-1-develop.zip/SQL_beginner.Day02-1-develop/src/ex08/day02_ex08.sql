SELECT DISTINCT person.name
FROM person
JOIN person_visits ON person_visits.person_id = person.id
JOIN pizzeria ON pizzeria.id = person_visits.pizzeria_id
JOIN menu ON menu.pizzeria_id = pizzeria.id
WHERE (pizza_name = 'pepperoni pizza' OR pizza_name = 'mushroom pizza') AND (address = 'Moscow' OR address = 'Samara') AND (gender = 'male')
ORDER BY 1 DESC