SELECT name, age 
FROM person
WHERE address = 'Kazan'