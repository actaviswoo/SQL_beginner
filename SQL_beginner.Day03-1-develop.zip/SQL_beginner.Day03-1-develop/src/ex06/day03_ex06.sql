WITH t AS
		(SELECT pizza_name, pizzeria.name AS pizzeria_name, price, menu.pizzeria_id
        FROM menu
        JOIN pizzeria ON pizzeria.id = menu.pizzeria_id)
SELECT p1.pizza_name, p1.pizzeria_name AS pizza_name_1, p2.pizzeria_name AS pizza_name_2, p1.price
FROM t p1
JOIN t p2 ON p1.price = p2.price AND p1.pizza_name = p2.pizza_name
WHERE p1.pizzeria_id > p2.pizzeria_id;