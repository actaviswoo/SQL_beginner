WITH woman AS(
	SELECT pizzeria.name AS pizzeria_name
	FROM menu
	JOIN pizzeria ON menu.pizzeria_id = pizzeria.id
	JOIN person_order ON person_order.menu_id = menu.id
    JOIN person ON person_order.person_id = person.id
	WHERE person.gender = 'female'),
    man AS (
	SELECT pizzeria.name AS pizzeria_name
	FROM menu
	JOIN pizzeria ON menu.pizzeria_id = pizzeria.id
	JOIN person_order ON person_order.menu_id = menu.id
    JOIN person ON person_order.person_id = person.id
	WHERE person.gender = 'male') 
(SELECT *
FROM man
EXCEPT
SELECT *
FROM woman)
UNION (
SELECT *
FROM woman
EXCEPT
SELECT *
FROM man )
ORDER BY pizzeria_name