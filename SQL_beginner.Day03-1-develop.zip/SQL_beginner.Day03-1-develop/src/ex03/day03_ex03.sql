WITH woman AS(
	SELECT pizzeria.name AS pizzeria_name
	FROM person_visits
	JOIN pizzeria ON person_visits.pizzeria_id = pizzeria.id
	JOIN person ON person_visits.person_id = person.id
	WHERE person.gender = 'female'),
    man AS (
	SELECT pizzeria.name AS pizzeria_name
	FROM person_visits
	JOIN pizzeria ON person_visits.pizzeria_id = pizzeria.id
	JOIN person ON person_visits.person_id = person.id
	WHERE person.gender = 'male') 
SELECT *
FROM woman
EXCEPT ALL
SELECT *
FROM man
UNION ALL (
SELECT *
FROM man
EXCEPT ALL
SELECT *
FROM woman )
ORDER BY pizzeria_name